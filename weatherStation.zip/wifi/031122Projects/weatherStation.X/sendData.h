/* 
 * File:   sendData.h
 * Author: M67732
 *
 * Created on November 3, 2022, 8:52 AM
 */

#ifndef SENDDATA_H
#define	SENDDATA_H

#define TEMP_DATA  0x00
#define PRES_DATA  0x11
#define HUMID_DATA  0x22
#define LIGHT_DATA  0x33

void sendTempData(void);
void sendPressureData(void);
void sendHumidData(void);
void sendLightData(void);
void sendAllSensorData(void);

#endif	/* SENDDATA_H */

