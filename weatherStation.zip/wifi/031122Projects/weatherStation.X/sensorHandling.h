#ifndef _SENSORHANDLING_H
#define	_SENSORHANDLING_H

#include <xc.h>
#include <stdint.h>

uint16_t temp_string; // Temperature
uint16_t press_string; // Pressure
uint16_t humid_string; // Humidity
uint16_t light_string; // Ambient Light
/**
  Section: Weather Click Driver APIs
 */

void WeatherStation_initialize(void);
void WeatherClick_readSensors(void);
void WeatherStation_Print(void);

#endif
