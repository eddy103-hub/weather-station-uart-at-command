/*
 * File:   sendData.c
 * Author: M67732
 *
 * Created on November 3, 2022, 8:55 AM
 */


#include <xc.h>
#include "sendData.h"
#include "mcc_generated_files/uart3.h"
#include "sensorHandling.h"

#define _XTAL_FREQ 1000000UL

uint8_t hiByte = 0;
uint8_t lowByte = 0;
extern uint16_t light_raw;
extern uint16_t temp_string; // Temperature
extern uint16_t press_string; // Pressure
extern uint16_t humid_string; // Humidity

void sendTempData(void) {
    hiByte = temp_string >> 8;
    lowByte = temp_string;
    while (!UART3_is_tx_ready());
    UART3_Write(TEMP_DATA);
    while (!UART3_is_tx_ready());
    UART3_Write(hiByte);
    while (!UART3_is_tx_ready());
    UART3_Write(lowByte);
    __delay_ms(100);
}

void sendPressureData(void) {
    hiByte = press_string >> 8;
    lowByte = press_string;
    while (!UART3_is_tx_ready());
    UART3_Write(PRES_DATA);
    UART3_Write(hiByte);
    UART3_Write(lowByte);
    __delay_ms(100);

}

void sendHumidData(void) {
    hiByte = humid_string >> 8;
    lowByte = humid_string;
    while (!UART3_is_tx_ready());
    UART3_Write(HUMID_DATA);
    UART3_Write(hiByte);
    UART3_Write(lowByte);
    __delay_ms(100);

}

void sendLightData(void) {

    hiByte = light_raw >> 8;
    lowByte = light_raw;
    while (!UART3_is_tx_ready());
    UART3_Write(LIGHT_DATA);
    UART3_Write(hiByte);
    UART3_Write(lowByte);
    __delay_ms(100);

}

void sendAllSensorData(void) {
    sendTempData();
    sendPressureData();
    sendHumidData();
    sendLightData();
}